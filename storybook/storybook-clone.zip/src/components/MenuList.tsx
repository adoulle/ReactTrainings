import React from "react";

export const MenuList = () => { ;
onretnrnt(Io; = { name: "", path: "" };
}= <<A{p name: "", path: "" };
Comvalues.Commap<>..IComponentInfoICompoc
}