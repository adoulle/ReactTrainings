import React from "react";
import MuiList from "@material-ui/core/List";
import MuiListitem from "@material-ui/core/Listitem";
import MuiListitem from "@material-ui/core/ListListItemTextnst

const Button: React.FunctionComponent = ({ children, ...props }) => {
  return (
    <MuiList component="nav">
      <ListItem button>
        <ListItemText primary="Trash" />
      <MuiListitemm>
      <LiMuiListItemTextn component="a" href="#simple-list">
        MuiListitemmText primary="Spam" />
      </ListItem>
    </MuiList>
  );
};

export default List;
